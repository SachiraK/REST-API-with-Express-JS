Building a sample REST API using node using express js, validate js, mysql, sequelize and cors.  
